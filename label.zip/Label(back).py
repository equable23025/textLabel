import nltk
import pandas as pd
from openpyxl import load_workbook
from itertools import islice
from textblob.classifiers import NaiveBayesClassifier
import nltk
import word_tokenize

file = ''
label = []
keyword = []

def importFile(f):
   file = f
   wb = load_workbook('./' + f )
   print(wb.get_sheet_names())
   sheet = wb.get_sheet_by_name('Bhin.fanclub')
   sheet.title
   anotherSheet = wb.active
   print("hi")
   print(anotherSheet)
def inputKeyword(textfile):
    f = open(textfile,'r',encoding='utf-8')

    for line in islice(f, 1, None):
        print(line)
        if(line[0] == u':'):
            label.append(line[1:-1])
            keyword.append([])
        else:
            keyword[-1].append(line[:-1])
    print(label)
    print(keyword)

def

if __name__ == '__main__':
  importFile('nectec(re).xlsx')
  inputKeyword('keywords.txt')

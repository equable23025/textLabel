from nltk.corpus import names
from openpyxl import load_workbook
from itertools import islice
labeled_names = []
keyword = []

def sheetToDatSet(f):
    file = f
    wb = load_workbook('./' + f )
    print(wb.get_sheet_names())
    sheet = wb.get_sheet_by_name('Bhin.fanclub')
    i = 2
    labeled_names = []
    while sheet['D'+str(i)].value != None:
        labeled_names.append((sheet['D'+str(i)].value, sheet['G'+str(i)].value))
        i+=1

    print(labeled_names)
   # print(sheet.title)
   # anotherSheet = wb.active
   # print(anotherSheet)
def getKeyword(textfile):
    f = open(textfile,'r',encoding='utf-8')
    keyword = []
    word = ''
    for line in islice(f, 1, None):
        print(line)
        if(line[0] == u':'):
            word = line[1:-1]
        else:
            keyword.append((word, line[:-1]))
    print(keyword)

def feature():


if __name__ == '__main__':
    # sheetToDatSet('nectec(re).xlsx')
    getKeyword('keywords.txt')
